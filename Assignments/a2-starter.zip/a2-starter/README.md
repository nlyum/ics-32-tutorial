ICS32 Assignment 2: Journal

This assignment includes the following starter files:

a2.py : Use this file as the main module for your program.
input_processor.py : Use this file for your user interface module.
Profile.py : Use this file to manage saving and loading of user data. Do not edit.

Please visit the course Canvas for a detailed overview of the assignment.
